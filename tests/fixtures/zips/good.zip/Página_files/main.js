document.querySelectorAll(".botao").forEach(function (b) {
  b.addEventListener("click", function () { b.textContent = "Carregando…"; });
});
