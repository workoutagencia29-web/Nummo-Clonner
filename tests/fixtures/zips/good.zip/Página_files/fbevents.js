/*! fbevents.js (cópia salva pelo navegador — rastreador que deve ser removido) */
(function(){window.fbq&&window.fbq.queue&&(window.fbq.loaded=true);})();
